package gr.aueb.cf.ch7;

public class CopiesToStrings {

    public static void main(String[] args) {
        String s = "Coding Factory";
        String clone;

        // Reference copy = Shallow copy
         clone = s;
    }
}
